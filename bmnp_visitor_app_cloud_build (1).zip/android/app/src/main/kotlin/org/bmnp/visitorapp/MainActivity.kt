package org.bmnp.visitorapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
